# Exact manual configuration

Use absolute paths inside the product folder. Save JSON as UTF-8. Supplying main, carousel, detail, colors, sizes, and the manual color count activates the fast path and avoids redundant full-folder visual statistics.

```json
{
  "folderPath": "E:\\product-folder",
  "title": "DX-xxxx",
  "titleSource": "operator",
  "templateId": 3359750,
  "templateSource": "manual",
  "categoryIds": [10761],
  "price": 999,
  "stock": 999,
  "goodsNo": "",
  "subtitle": "",
  "manualMedia": {
    "mainFile": "E:\\product-folder\\white.jpg",
    "showFiles": [
      "E:\\product-folder\\color-1.jpg",
      "E:\\product-folder\\大图\\zipper-closeup.jpg",
      "E:\\product-folder\\大图\\fabric-closeup.jpg"
    ],
    "detailFiles": ["E:\\product-folder\\750\\750_01.jpg"],
    "detailColorCount": 1,
    "expectedBackCount": 0,
    "ignoreUnboundSideCandidates": true,
    "sizes": [
      { "id": 41, "name": "S", "note": "" },
      { "id": 42, "name": "M", "note": "" }
    ],
    "colors": [
      {
        "id": 6,
        "systemName": "黑色",
        "note": "黑色",
        "front": "E:\\product-folder\\black-front.jpg",
        "back": "",
        "sizeIds": [41, 42]
      }
    ]
  }
}
```

Rules:

- Color and size IDs must be unique, valid backend values.
- `detailColorCount` must equal `colors.length`.
- Every `sizeIds` value must exist in `sizes`.
- `expectedBackCount` must equal the number of non-empty `back` fields.
- Set `ignoreUnboundSideCandidates` only after reviewing excluded candidates.
- Put confirmed color/front images first in `showFiles`, followed by useful close-ups selected from the first level of `大图`.
- Never put backs, repeated fronts, `大图\png`, or `640`/`750`/`790` detail sequences in `showFiles`.
- Keep `showFiles` at 24 images or fewer; retain all color/front images before close-ups.
- Keep `goodsNo` and `subtitle` empty unless exact values were supplied.
