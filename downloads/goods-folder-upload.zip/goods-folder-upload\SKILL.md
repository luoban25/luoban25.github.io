---
name: goods-folder-upload
description: Fast, verified XD goods creation from Windows product folders using the local pure-code uploader. Use when the user asks to scan, preflight, map, upload, batch-create, correct, or verify goods on xdggs.p3.smtul.com, especially clothing folders with detail pages, exact color notes, size matrices, carousel images, and per-color front/back base images.
---

# Goods Folder Upload

Use the local Node uploader only. Keep Chrome cookies and tokens inside the existing browser session; never print or persist them.

## Required inputs

Before creation, obtain or confirm: exact title, template ID, category ID, price, stock, and source folder. Never infer `goods_no` or `subtitle`; leave both blank unless the user or source record supplies exact values. Never list or delist.

## Choose the path

- Use automatic preflight when folder naming, template colors, sizes, and base images match cleanly.
- Use exact manual mapping as soon as color count, size range, front/back pairing, or carousel routing is uncertain. Read [references/manual-config.md](references/manual-config.md), prepare one UTF-8 JSON config, and use `scripts/invoke-manual-upload.ps1`.
- For an explicit template ID, do not audit similar templates unless troubleshooting; this is the fast path.
- For a user-requested batch, preflight folders independently if useful, but create and verify one product at a time.

## Fast verified workflow

1. Confirm the local service, logged-in Chrome session, and uploader version `20260727-29` or newer. Stop if `/api/status` reports an older or missing `detectorVersion`.
2. Scan the folder. Inspect the canonical color page, size table, likely SKU base images, and a contact sheet of the direct files in `大图` when that directory exists; expand inspection only when these disagree.
3. Check the exact title for duplicates before uploading.
4. Build a final plan with exact color `note` values, authoritative sizes, per-color `sizeIds`, fronts, real backs, price, stock, and media counts.
5. Run the reusable script without `-Create`; review its compact plan summary.
6. After confirmation, run it once with `-Create`.
7. Read `getInfo` back and verify every required field before reporting success.

Automatic CLI remains available for clean folders:

```powershell
npm run upload:folder -- --folder "E:\\product-folder" --title "DX-xxxx" --template 3359750 --category 10761 --price 999 --stock 999 --confirm-visual --create --json
```

Exact manual plan preview and creation:

```powershell
powershell -ExecutionPolicy Bypass -File "<skill>\scripts\invoke-manual-upload.ps1" -ConfigPath "C:\tmp\goods-plan.json"
powershell -ExecutionPolicy Bypass -File "<skill>\scripts\invoke-manual-upload.ps1" -ConfigPath "C:\tmp\goods-plan.json" -Create
```

## Accuracy rules

- Treat detail-page color labels as storefront truth. Backend color IDs may be approximate, but each exact source label must be stored in `note`.
- Treat detail-page size tables as authoritative. Rebuild the SKU matrix, including per-color or male/female ranges; verify SKU count equals the sum of all color-size combinations.
- A manual `detailColorCount` is authoritative and skips image-based color estimation.
- Manual `sizes` replace template sizes directly; put applicable IDs in each color's `sizeIds`.
- Set `ignoreUnboundSideCandidates: true` only after visually reviewing the candidate images and supplying `expectedBackCount`. This records the manual review decision, skips redundant full-folder visual statistics, and prevents reviewed raw/model images from becoming false blockers.
- Every color needs a real front. Bind a real back when present; otherwise leave back empty. Never substitute a front as a back.
- Upload every bound front/back image through `/super/goods/uploadSide` with the same processing fields as the XD editor: `valueId`, `sideCode`, `sideImg`, `a`, and `s`. When a configured side background exists, enable automatic processing and require a processed `_s_<width>_<height>_s_` response; a raw `.jpg` response is a hard failure even when the upload endpoint returned success.
- Include the side-processing fields in the upload-cache identity. Never reuse a raw or differently configured side-image cache entry.
- A newly created product can generate its final front/back side backgrounds only after the first create. If any configured SKU side remains raw, reprocess it against the newly read-back `other.sides` background and update the same goods ID; never call create again.
- Order carousel images as: confirmed color/front product images first, then useful product close-ups such as fabric, zipper, cuff, pocket, hood, lining, label, and workmanship. When such close-ups exist directly inside `大图`, include the reviewed files in manual `showFiles`; this is required, not optional.
- Exclude backs, repeated color/front images, detail-page sequences, `640`, `750`, `790`, `大图\png`, duplicate resolutions, videos, and raw model dumps from carousel. Direct files inside `大图` are allowed only through an exact manual mapping after visual review.
- Keep carousel at no more than 24 images. Preserve every confirmed color/front image first, then add the most useful non-duplicate close-ups in natural filename order until the limit.
- Unified price and stock must be written to the base record and every SKU.

## Create-once recovery

- Never retry `/super/goods/create` after an ambiguous result.
- If creation returns a goods ID but the goods-list endpoint fails, do not classify the product as failed solely for that reason. Read `/super/goods/getInfo` directly, verify all content/SKU/media fields, and report the list-status check as a warning.
- Permission failures, missing IDs, duplicate titles, or failed `getInfo` remain hard stops.

## Completion report

Report the backend URL and verify title, category, base price, all SKU prices/stocks, exact color notes, sizes, SKU count, carousel count, detail count, front count, real-back count, and that every configured front/back URL is a processed side-image URL. Mention any list-status warning. Do not claim success without `getInfo` verification.
