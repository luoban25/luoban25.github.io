param(
    [Parameter(Mandatory = $true)]
    [string]$ConfigPath,
    [switch]$Create,
    [string]$BaseUrl = 'http://127.0.0.1:8787',
    [ValidateRange(30, 3600)]
    [int]$TimeoutSeconds = 900
)

$ErrorActionPreference = 'Stop'

function Post-LocalJson {
    param([string]$Path, [object]$Value)
    $json = $Value | ConvertTo-Json -Depth 100 -Compress
    $bytes = [Text.Encoding]::UTF8.GetBytes($json)
    Invoke-RestMethod -Uri "$BaseUrl$Path" -Method Post -Headers $script:Headers -ContentType 'application/json; charset=utf-8' -Body $bytes
}

if (-not (Test-Path -LiteralPath $ConfigPath -PathType Leaf)) {
    throw "Config file not found: $ConfigPath"
}

$status = Invoke-RestMethod -Uri "$BaseUrl/api/status" -Method Get
if (-not $status.ok) {
    throw 'Local uploader is not connected to the logged-in Chrome session.'
}
$minimumUploaderVersion = '20260727-29'
if ([string]::CompareOrdinal([string]$status.detectorVersion, $minimumUploaderVersion) -lt 0) {
    throw "Local uploader version $($status.detectorVersion) is too old. Required: $minimumUploaderVersion or newer."
}

$configText = [IO.File]::ReadAllText((Resolve-Path -LiteralPath $ConfigPath), [Text.Encoding]::UTF8)
$config = $configText | ConvertFrom-Json
foreach ($field in @('folderPath', 'title', 'templateId', 'categoryIds', 'price', 'stock', 'manualMedia')) {
    if ($null -eq $config.$field -or [string]::IsNullOrWhiteSpace([string]$config.$field)) {
        throw "Required config field is missing: $field"
    }
}

$session = Invoke-RestMethod -Uri "$BaseUrl/api/session" -Method Get
$script:Headers = @{
    Origin = $BaseUrl
    'X-Local-Uploader-Nonce' = $session.nonce
}

$preflight = Post-LocalJson -Path '/api/preflight' -Value $config
$draft = $preflight.draft
$planResult = Post-LocalJson -Path '/api/plan' -Value @{ draft = $draft }

$preview = [ordered]@{
    ok = [bool]$planResult.ok
    blockers = @($planResult.blockers)
    title = $planResult.plan.identity.name
    templateId = $planResult.plan.identity.templateId
    categoryIds = @($planResult.plan.identity.categoryIds)
    price = $draft.price
    stock = $draft.stock
    carousel = $planResult.plan.totals.carousel
    detail = $planResult.plan.totals.detail
    colors = @($planResult.plan.specs.colors | ForEach-Object { $_.note })
    sizes = @($planResult.plan.specs.sizes | ForEach-Object { $_.name })
    skus = $planResult.plan.totals.skus
    fronts = $planResult.plan.totals.fronts
    backs = $planResult.plan.totals.actualBacks
    warnings = @($planResult.warnings)
}
$preview | ConvertTo-Json -Depth 20

if (-not $Create) {
    return
}
if (-not $planResult.ok) {
    throw 'The final plan has blockers; no goods record was created.'
}

$draft | Add-Member -NotePropertyName operatorConfirmed -NotePropertyValue $true -Force
$draft | Add-Member -NotePropertyName templateConfirmed -NotePropertyValue $true -Force
$draft | Add-Member -NotePropertyName publish -NotePropertyValue $false -Force
$draft | Add-Member -NotePropertyName plan -NotePropertyValue $planResult.plan -Force
$draft | Add-Member -NotePropertyName confirmedPlanDigest -NotePropertyValue $planResult.plan.planDigest -Force

$jobStart = Post-LocalJson -Path '/api/create-job' -Value @{ draft = $draft }
$jobId = $jobStart.job.id
$deadline = [DateTime]::UtcNow.AddSeconds($TimeoutSeconds)
do {
    Start-Sleep -Seconds 1
    $jobResponse = Invoke-RestMethod -Uri "$BaseUrl/api/jobs/$jobId" -Method Get
    $state = [string]$jobResponse.job.state
    if ([DateTime]::UtcNow -gt $deadline) {
        throw "Timed out waiting for upload job: $jobId"
    }
} while ($state -in @('queued', 'running'))

$result = [ordered]@{
    ok = ($state -eq 'succeeded')
    jobId = $jobId
    state = $state
    goodsId = $jobResponse.job.result.goodsId
    goodsUrl = $jobResponse.job.result.goodsUrl
    verification = $jobResponse.job.result.verify
    reportPath = $jobResponse.job.result.reportPath
    error = $jobResponse.job.error
}
$result | ConvertTo-Json -Depth 30
if ($state -ne 'succeeded') {
    throw "Upload job failed. Do not retry create automatically. Job: $jobId"
}
